**Increased Player Career Mode Level Cap**

**Mod Version**: 1.0

```
This mod increases the level cap in player career mode from 40 to 99

IT DOESN'T GIVE YOU 99 LEVEL...
```

**Edited files:**
```
    - root\Legacy\dlc\dlc_FootballCompEng\dlc\FootballCompEng\data\PlayerGrowth\player_growth.json
```

**Changelog:**
```

```
**How to install:**
```
1. Unzip archive
2. Move the LiveEditorMods folder to root game directory (replace files if needed) <https://i.imgur.com/xsGvlGi.png>
3. Run the game & Live Editor
4. Load Player Career Mode
```

https://i.imgur.com/7puQBqY.png