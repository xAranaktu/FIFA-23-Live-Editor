**World Cup LE Fix**

Allows you to enter the world cup mode while playing with the live editor

**Mod Version**: 1.1
**Author**: FIFER (?)


**Edited files:**
```
    - data/ui/nav/worldCupMainMenuFlow.nav
```

**Changelog:**
```
1.0:
    - Initial release

1.1:
    - Added support for Women's World Cup
    - Redid the edit for mens, EA updated the nav file so the old version might have some bugs, this should work better
```

**How to install:**
```
1. Unzip archive
2. Move the root folder to C:\FIFA 23 Live Editor\mods (replace files if needed) <https://i.imgur.com/8BOzvnu.png>
3. Run the game & Live Editor

```
