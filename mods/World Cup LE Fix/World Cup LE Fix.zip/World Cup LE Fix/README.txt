**World Cup LE Fix**

Allows you to enter the world cup mode while playing with the live editor

**Mod Version**: 1.0
**Author**: FIFER (?)


**Edited files:**
```
    - data/ui/nav/worldCupMainMenuFlow.nav
```

**Changelog:**
```
1.0:
    - Initial release
```

**How to install:**
```
1. Unzip archive
2. Move the LiveEditorMods folder to root game directory (replace files if needed) <https://i.imgur.com/xsGvlGi.png>
3. Run the game & Live Editor

```
